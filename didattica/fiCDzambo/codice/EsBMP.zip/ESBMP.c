#include "Tipi.h"
#include "GestBMP.h"

void main (void)
{
	int x,y;
	BYTE Immagine[200][200];

	for (y=0;y<200;y++) {
		for (x=0;x<200;x++) {
			Immagine[x][y] = x;
		}
	}

	SalvaImmagineBMP ("PROVA.BMP",Immagine);
}