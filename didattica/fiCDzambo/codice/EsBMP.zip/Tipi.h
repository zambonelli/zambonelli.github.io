/*
	Nuovi tipi di dato comodi da utilizzare nella gestione dei
	file di immagini.
*/

typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned long int DWORD;
typedef signed long int LONG;
