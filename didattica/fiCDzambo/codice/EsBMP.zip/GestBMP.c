#include "GestBMP.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*
	E' importante assicurarsi che il compilatore non allinei i
	membri delle strutture a indirizzi multipli di 4 byte, come
	spesso avviene nei compilatori a 32bit. Accertarsi dunque
	che le opzioni impongano un allineamento al byte.
*/

typedef struct tagBITMAPFILEHEADER { // bmfh 
	WORD    bfType; 
	DWORD   bfSize; 
	WORD    bfReserved1; 
	WORD    bfReserved2; 
	DWORD   bfOffBits; 
} BITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER { // bmih 
	DWORD  biSize; 
	LONG   biWidth; 
	LONG   biHeight; 
	WORD   biPlanes; 
	WORD   biBitCount;
	DWORD  biCompression; 
	DWORD  biSizeImage; 
	LONG   biXPelsPerMeter; 
	LONG   biYPelsPerMeter; 
	DWORD  biClrUsed; 
	DWORD  biClrImportant; 
} BITMAPINFOHEADER; 

typedef struct tagRGBQUAD { // rgbq 
	BYTE    rgbBlue; 
	BYTE    rgbGreen; 
	BYTE    rgbRed; 
	BYTE    rgbReserved; 
} RGBQUAD;

#define BI_RGB 0L

void SalvaImmagineBMP (char *filename, BYTE Immagine[200][200])
{
	BITMAPFILEHEADER bfh;
	BITMAPINFOHEADER bih;
	RGBQUAD rgbquad;
	FILE *f;
	int y,w,h;
	
	w = 200;
	h = 200;

	f = fopen (filename,"wb");

	/* Scrivo le informazioni sul file */
	bfh.bfType = 0x4D42; /* BM */
	bfh.bfSize = w*h+sizeof(bfh)+sizeof(bih)+256*sizeof(RGBQUAD);
	bfh.bfReserved1 = bfh.bfReserved2 = 0;
	bfh.bfOffBits = sizeof(bfh)+sizeof(bih)+256*sizeof(RGBQUAD);
	fwrite (&bfh,sizeof(bfh),1,f);

	/* Scrivo le informazioni sull'immagine */
	bih.biSize = sizeof(bih);
	bih.biWidth = w;
	bih.biHeight = h;
	bih.biPlanes = 1;
	bih.biBitCount = 8;
	bih.biCompression = BI_RGB;
	bih.biSizeImage = 0;
	bih.biXPelsPerMeter = 0;
	bih.biYPelsPerMeter = 0; 
	bih.biClrUsed = 0; 
	bih.biClrImportant = 0; 
	fwrite (&bih,sizeof(bih),1,f);

	/* Scrivo la palette, cio� 256 quaterne di BYTE */
	rgbquad.rgbReserved = 0;
	for (y=0;y<256;y++) {
		rgbquad.rgbRed = rgbquad.rgbGreen = rgbquad.rgbBlue = (BYTE) y ;
		fwrite (&rgbquad,sizeof(rgbquad),1,f);
	}

	/* Scrivo l'immagine in un colpo solo */
	fwrite (Immagine,1,w*h,f);

	fclose (f);
}
