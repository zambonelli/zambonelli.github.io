/*
	File di include per il salvataggio di una matrice 200x200
	in un file BMP.
*/

#include "Tipi.h"

void SalvaImmagineBMP (char *filename, BYTE Immagine[200][200]);
