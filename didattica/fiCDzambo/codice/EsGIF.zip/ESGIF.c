#include "Tipi.h"
#include "GestGIF.h"

void main (void)
{
	int x,y;
	BYTE Immagine[200][200];

	for (y=0;y<200;y++) {
		for (x=0;x<200;x++) {
			Immagine[x][y] = x*y;
		}
	}

	SalvaImmagineGIF ("PROVA.GIF",Immagine);
}