/*
	File di include per il salvataggio di una matrice 200x200
	in un file GIF.
*/

#include "Tipi.h"

void SalvaImmagineGIF (char *filename, BYTE Immagine[200][200]);
