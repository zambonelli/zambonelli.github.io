#include "GestGIF.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "GIF_LIB.H"

void SalvaImmagineGIF (char *filename, BYTE Immagine[200][200])
{
	int i,w,h;
	BYTE ColorMap[256][3];

	for (i=0;i<256;i++) {
		ColorMap[i][0] = ColorMap[i][1] = ColorMap[i][2] = (BYTE) i;
	}

	w = 200;
	h = 200;

	i = EGifOpenFileName (filename);

	EGifPutScreenDesc (w,h,8,0,8,ColorMap);

	EGifPutImageDesc(0,0,w,h,8);

	for (i=0;i<h;i++) {
		EGifPutLine((BYTE *)(Immagine)+i*w,w);
	}

	EGifCloseFile ();
}
