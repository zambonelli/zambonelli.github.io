import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class VectorHandler {

Vector vettoreclienti;
// uso un vector
// non sapendo a priori quanti clienti avro, il vettore e' estensibile

public VectorHandler() {
	vettoreclienti = new Vector();	
}	

public void aggiungiclienti(Clienti nuovocliente) {//aggiunge un elemento
		vettoreclienti.addElement(nuovocliente);
}

public int contaclienti(){//riporta la lunghezza del vettore
        return vettoreclienti.size();

}

public Clienti nome (int i) { //seleziona l'elemento i-esimo del vettore
return (Clienti) vettoreclienti.elementAt(i);
}	

public void rimuovi(Clienti client) {//rimuove un elemento
		vettoreclienti.remove(client);
}


}