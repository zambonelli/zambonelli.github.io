import java.io.*;
import java.net.*;
import java.lang.*;

public class Client {

public static void main (String args[]){

BufferedReader br = null;
String str = null;
String username = null;
InputStream is = null;
Socket cs = null;
PrintStream pw = null;
BufferedReader stdIn = null;
String str1 = null;
String str2 = null;
int i = 0;


try {

    cs = new Socket ("localhost",1234);
    // crea la socket e la pone in comunicazione con il server

    br = new BufferedReader (new InputStreamReader (cs.getInputStream()));
    
    pw = new PrintStream  (cs.getOutputStream());
    //predisposizione a ricevere ed inviare

    stdIn = new BufferedReader ( new InputStreamReader (System.in));
    //buffer per stampare quello che digito

    str = br.readLine();
    //legge il messaggio di benvenuto

    System.out.println(str);

    System.out.println ("Inserire Username (max 20 caratteri)");

    username = stdIn.readLine();//riceve username

    i = username.length();//conta quanto e lungo l'username



    while (i==0 || i>20) {//Controllo username

           System.out.println ("Username non corretto");

           System.out.println ("Inserire Username (max 20 caratteri)");

           username = stdIn.readLine();

           i = username.length();

        }



    pw.println(username);//dopo il controllo puo inviarlo


    new ThreadClient1(br).start();
    //il trhread serve per ricevere

    
    // il programma principale server per inviare
    while (true){
	


           str2 = stdIn.readLine();//Client scrive poi invia 

           pw.println(str2);


         }	

 }			
catch (Exception e){
	 
	System.out.println("Errore Connessione Server");

 } // end try catch	

  }  // end metodo
 
} // end class