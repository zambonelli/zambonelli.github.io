import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class ThreadClient1 extends Thread {


private BufferedReader input;	


public ThreadClient1 (BufferedReader input){
    this.input = input;
  }	

public void run(){

try{
   while (true){
        String str1 = input.readLine();//client riceve

        System.out.println(str1);
       }
    }
    catch (IOException e) {
                  System.out.println("Errore in ascolto");
				}	
 }
}
