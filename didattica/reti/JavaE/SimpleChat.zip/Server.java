import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class Server {


public static void main(String[] args) {

VectorHandler vector_hand = new VectorHandler();

System.out.println ("Server in attesa...");

ServerSocket ss = null;

try{

ss = new ServerSocket (1234); 



while (true){ //Server rimane in attesa 

Socket clientsocket = ss.accept();// Attesa socket

new ThreadServer1 (clientsocket, vector_hand).start();

}
}

catch (Exception e){
System.out.println("Errore di apertura porta");

}
}
}