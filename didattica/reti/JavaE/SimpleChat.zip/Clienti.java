import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class Clienti{

String nome;
PrintStream ps;
//String hobby;
//Image mypicture;
//Date birth;



public Clienti (PrintStream ps, String nome){

this.ps = ps;
this.nome = nome;


}

public String getNome(){

return nome;
}

public PrintStream getStream() {
return ps;
}

}	