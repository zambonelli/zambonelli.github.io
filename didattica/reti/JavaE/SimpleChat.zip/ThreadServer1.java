import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class ThreadServer1 extends Thread {

Socket client;
PrintStream p = null;
BufferedReader br = null;
VectorHandler server;
Clienti cliente;

public ThreadServer1 (Socket socket, VectorHandler server){

	System.out.println("E' arrivato il/a nuovo/a amico/a da "+socket.getInetAddress());
	client = socket;
	this.server = server;
}

public void run(){

	try{
		System.out.println ("Server pronto a ricevere nuovi amici sulla porta 1234");

		br = new BufferedReader (new InputStreamReader (client.getInputStream()));//predisposizione a ricevere

		p = new PrintStream (client.getOutputStream());//predisposizione ad inviare

		p.println("::BENVENUTO NELLA MIA CHAT::");

		String myname = br.readLine();//riceve username

		System.out.println ("E' entrato il nuovo amico "+ myname);

		p.println("::CIAO "+ myname + "! ORA SEI CONNESSO/A ALLA CHAT!!::");//invia il mess di benvenuto

		cliente = new Clienti (p,myname);//aggiorna il vettore dei clienti connessi

		server.aggiungiclienti(cliente);



		int numeclienti = server.contaclienti();//conta quanti clienti sono presenti nel vettore (dentro al ciclo perche altrimenti se fosse fuori ogni thread conterebbe diversamente 


		for (int y=0;y<numeclienti;y++) {//li spedisce ad ogni elemento del vettore che contiene tutti i client

			Clienti current_client = server.nome(y);//selezione ogni singolo elemento del vettore
            
            PrintStream ps = current_client.getStream();
            
			ps.println(myname+" e' entrato in chat");//invia ad ogni elemento i-esimo

			}	

	
	while (true){//Ricezione ed invio messaggi 

		String str1 = br.readLine();//Server legge i messaggi che gli arrivano

		System.out.println("<"+myname+"> " + str1);

		int numclienti = server.contaclienti();//conta quanti clienti sono presenti nel vettore (dentro al ciclo perche altrimenti se fosse fuori ogni thread conterebbe diversamente 


		for (int i=0;i<numclienti;i++) {//li spedisce ad ogni elemento del vettore che contiene tutti i client

			Clienti cliente1 = server.nome(i);//selezione ogni singolo elemento del vettore
            
            PrintStream ps = cliente1.getStream();
			
			ps.println("<"+myname+"> "+str1);//invia ad ogni elemento i-esimo

			}	

		}	


	} // try
	catch (Exception e) 
	{
		System.out.println ("Errore di connessione con il client o il client si � disconnesso");

		int numerclienti = server.contaclienti();//conta quanti clienti sono presenti nel vettore (dentro al ciclo perche altrimenti se fosse fuori ogni thread conterebbe diversamente 


		for (int j=0;j<numerclienti;j++) 
			{//li spedisce ad ogni elemento del vettore che contiene tutti i client

			Clienti cliente3 = server.nome(j);//selezione ogni singolo elemento del vettore

			cliente3.ps.println("Un'amico si e' disconnesso");//invia ad ogni elemento i-esimo


			}	

  	
  	server.rimuovi(cliente);//Aggiorna il vettore se qualc esce

	 }  // end try catch
  }

}	